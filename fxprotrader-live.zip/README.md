# FXProTrader Fullstack Project

## Cách chạy
- Cài Node.js
- Vào backend: `npm install && node app.js`
- Vào frontend: `npm install && npm run dev`
